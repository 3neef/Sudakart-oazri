$(document).ready(function(){
   
    $('#count-category-product-select').on('change',function(){
        var perpage = $(this).val();
        var category = $('#product-category-area').data('id');
        
        $.ajaxSetup({
            headers:{
                'X-CSRF-TOKEN':$('meta[name="csrf_token"]').attr('content')
            }
        });

        $.ajax({
            url : '/ProductsPerPage',
            type : 'get',
            data : {perpage : perpage,category:category},
            success:function(result){
               $('#product-category-area').html(result);
            }
        })

    });

    

});