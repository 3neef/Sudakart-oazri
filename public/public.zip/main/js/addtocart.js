/*=====================
 24. add to cart sidebar js
 ==========================*/
 function openCart() {
    document.getElementById("cart_side").classList.add('open-side');
}

function closeCart() {
    document.getElementById("cart_side").classList.remove('open-side');
}
